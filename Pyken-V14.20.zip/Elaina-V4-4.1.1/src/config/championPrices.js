export default {
    "ChampsPrice": [
        {
            "Cost": 1,
            "description": "1 Blue Essence (PBE)"
        },
        {
            "Cost": 450,
            "description": "450 Blue Essence"
        },
        {
            "Cost": 1350,
            "description": "1350 Blue Essence"
        },
        {
            "Cost": 3141,
            "description": "3141 Blue Essence"
        },
        {
            "Cost": 3150,
            "description": "3150 Blue Essence"
        },
        {
            "Cost": 4444,
            "description": "4444 Blue Essence"
        },
        {
            "Cost": 4800,
            "description": "4800 Blue Essence"
        },
        {
            "Cost": 6300,
            "description": "6300 Blue Essence"
        },
        {
            "Cost": 7800,
            "description": "7800 Blue Essence"
        },
        {
            "Cost": "All",
            "description": "All"
        }
    ]
}